package notes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Savepoint;
import java.time.LocalDateTime;
import java.util.Map;

import org.javatuples.Pair;
import org.javatuples.Triplet;

import prerna.auth.AccessToken;
import prerna.auth.User;
import prerna.engine.api.IRDBMSEngine;
import prerna.sablecc2.om.PixelDataType;
import prerna.sablecc2.om.execptions.SemossPixelException;
import prerna.sablecc2.om.nounmeta.NounMetadata;
import prerna.sablecc2.reactor.AbstractReactor;
import prerna.util.Utility;
import workflow.WorkflowHelper;
import workflow.WorkflowStatementSet;

public class MoveNoteReactor extends AbstractReactor {
	
	public MoveNoteReactor() {
		this.keysToGet = new String[] { "id", "guid", "targetStage", "targetUser" };
	}

	public NounMetadata execute() {
		organizeKeys();

		String id = this.keyValue.get(this.keysToGet[0]);
		if (id == null || id.isEmpty()) {
			throw new IllegalArgumentException("Must provide a valid id");
		}

		String guid = this.keyValue.get(this.keysToGet[1]);
		if (guid == null || guid.isEmpty()) {
			throw new IllegalArgumentException("Must provide a valid guid");
		}

		String targetStage = this.keyValue.get(this.keysToGet[2]);
		if (targetStage == null || targetStage.isEmpty()) {
			throw new IllegalArgumentException("Must provide a valid target stage");
		}

		String targetUser = this.keyValue.get(this.keysToGet[3]);

		// access database
		IRDBMSEngine database = (IRDBMSEngine) Utility.getEngine(NotesConstants.DB);

		// create a new WorkflowHelper
		WorkflowHelper wh = new WorkflowHelper(NotesConstants.TABLE);
		Triplet<Connection, Savepoint, IRDBMSEngine> transaction = null;
		WorkflowStatementSet statements = null;
		Pair<WorkflowStatementSet, Map<String, Object>> movedItem = null;
		try {
			// connect to the db
			transaction = wh.startTransaction(database);

			// get the user
			User user = this.insight.getUser();
			if (user == null) {
				throw new IllegalArgumentException("You are not properly logged in");
			}
			AccessToken token = user.getAccessToken(user.getPrimaryLogin());
			String userId = token.getId();

			// current time
			java.sql.Timestamp currentTime = java.sql.Timestamp.valueOf(LocalDateTime.now());

			// set the system user
			if (targetUser == null || targetUser.isEmpty()) {
				targetUser = wh.getSystemUser();
			}

			// move it to a new stage
			
			movedItem = wh.moveItem(transaction, 
					id, 
					guid, 
					userId, 
					targetUser, 
					targetStage, 
					false, 
					currentTime);

			if(movedItem != null && (statements=movedItem.getValue0()) != null) {
				for(PreparedStatement thisPs : statements) {
					thisPs.execute();
				}
				wh.commit(transaction.getValue0());
			} else {
				throw new IllegalArgumentException("Uncaught exception occurred preventing the note from being added to the workflow");
			}
		} catch (Exception e) {
			// rollback any changes
			wh.rollback(transaction);
			if (e.getMessage() == null || e.getMessage().isEmpty()) {
				throw new SemossPixelException("Error occurred trying to create the note. Detailed message = " + e.getMessage(), false);
			} else {
				throw new IllegalArgumentException(e.getMessage(), e);
			}
		} finally {
			// cleanup any changes
			if(statements != null) {
				statements.closeAll();
			}
			wh.endTransaction(transaction);
		}

		NounMetadata noun = new NounMetadata(movedItem.getValue1(), PixelDataType.MAP);
		noun.addAdditionalReturn(getSuccess("Successfully moved note:" + id + " to " + targetStage));
		return noun;
	}

}
