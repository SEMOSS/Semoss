package notes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Savepoint;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

import org.javatuples.Pair;
import org.javatuples.Triplet;

import prerna.auth.AccessToken;
import prerna.auth.User;
import prerna.engine.api.IRDBMSEngine;
import prerna.engine.impl.rdbms.RDBMSNativeEngine;
import prerna.sablecc2.om.PixelDataType;
import prerna.sablecc2.om.execptions.SemossPixelException;
import prerna.sablecc2.om.nounmeta.NounMetadata;
import prerna.sablecc2.reactor.AbstractReactor;
import prerna.util.Utility;
import workflow.WorkflowHelper;
import workflow.WorkflowStatementSet;

public class CreateNoteReactor extends AbstractReactor {

	public CreateNoteReactor() {
		this.keysToGet = new String[] { "description" };
	}

	public NounMetadata execute() {
		organizeKeys();

		String description = this.keyValue.get(this.keysToGet[0]);
		if (description == null || description.isEmpty()) {
			throw new IllegalArgumentException("Must provide a valid description");
		}

		// access database
		RDBMSNativeEngine database = (RDBMSNativeEngine) Utility.getEngine(NotesConstants.DB);

		// create a new WorkflowHelper
		WorkflowHelper wh = new WorkflowHelper(NotesConstants.TABLE);
		Triplet<Connection, Savepoint, IRDBMSEngine> transaction = null;
		WorkflowStatementSet statements = null;
		Pair<WorkflowStatementSet, Map<String, Object>> createdItem = null;
		PreparedStatement ps = null;
		try {
			// connect to the db
			transaction = wh.startTransaction(database);
			
			// generate an id
			String id = UUID.randomUUID().toString();

			// get the user
			User user = this.insight.getUser();
			if (user == null) {
				throw new IllegalArgumentException("You are not properly logged in");
			}

			AccessToken token = user.getAccessToken(user.getPrimaryLogin());
			String userId = token.getId();

			// current time
			java.sql.Timestamp currentTime = java.sql.Timestamp.valueOf(LocalDateTime.now());

			createdItem = wh.createInsert(
						transaction.getValue0(), 
						id, 
						userId, 
						NotesConstants.STAGES.INTAKE.getStage(),
						wh.getSystemUser(), 
						NotesConstants.STAGES.PENDING_APPROVAL.getStage(), 
						false,
						true,
						currentTime,
						currentTime);

			if(createdItem != null && (statements=createdItem.getValue0()) != null) {
				// create the prepared statement off of the same workflow item
				ps = transaction.getValue0().prepareStatement("INSERT INTO notes (id, description, guid, is_latest) VALUES (?,?,?,?)");
				int psIndex = 1;
				ps.setString(psIndex++, (String) createdItem.getValue1().get(WorkflowHelper.ID));
				ps.setString(psIndex++, description);
				ps.setString(psIndex++, (String) createdItem.getValue1().get(WorkflowHelper.GUID));
				ps.setBoolean(psIndex++, true);

				statements.addPreparedStatement(ps);
				
				// only execute if we added to the workflow
				// and able to pull the id to insert the description
				for(PreparedStatement thisPs : statements) {
					thisPs.execute();
				}
				wh.commit(transaction.getValue0());
			} else {
				throw new IllegalArgumentException("Uncaught exception occurred preventing the note from being added to the workflow");
			}
		} catch (Exception e) {
			// roll back any changes to the save point if possible
			wh.rollback(transaction);
			if (e.getMessage() == null || e.getMessage().isEmpty()) {
				throw new SemossPixelException("Error occurred trying to create the note. Detailed message = " + e.getMessage(), false);
			} else {
				throw new IllegalArgumentException(e.getMessage(), e);
			}
		} finally {
			// cleanup any changes
			if(statements != null) {
				statements.closeAll();
			}
			wh.endTransaction(transaction);
		}

		NounMetadata noun = new NounMetadata(createdItem.getValue1(), PixelDataType.MAP);
		noun.addAdditionalReturn(getSuccess("Successfully added note: " + description));
		return noun;
	}

}
