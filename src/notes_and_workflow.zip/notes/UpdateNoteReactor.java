package notes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Savepoint;
import java.time.LocalDateTime;
import java.util.Map;

import org.javatuples.Pair;
import org.javatuples.Triplet;

import prerna.auth.AccessToken;
import prerna.auth.User;
import prerna.engine.api.IRDBMSEngine;
import prerna.sablecc2.om.PixelDataType;
import prerna.sablecc2.om.execptions.SemossPixelException;
import prerna.sablecc2.om.nounmeta.NounMetadata;
import prerna.sablecc2.reactor.AbstractReactor;
import prerna.util.ConnectionUtils;
import prerna.util.Utility;
import workflow.WorkflowHelper;
import workflow.WorkflowStatementSet;

public class UpdateNoteReactor extends AbstractReactor {
	
	public UpdateNoteReactor() {
		this.keysToGet = new String[] { "id", "guid", "description" };
	}

	public NounMetadata execute() {
		organizeKeys();

		String id = this.keyValue.get(this.keysToGet[0]);
		if (id == null || id.isEmpty()) {
			throw new IllegalArgumentException("Must provide a valid id");
		}

		String guid = this.keyValue.get(this.keysToGet[1]);
		if (guid == null || guid.isEmpty()) {
			throw new IllegalArgumentException("Must provide a valid guid");
		}

		String description = this.keyValue.get(this.keysToGet[2]);
		if (description == null || description.isEmpty()) {
			throw new IllegalArgumentException("Must provide a valid description");
		}

		// access database
		IRDBMSEngine database = (IRDBMSEngine) Utility.getEngine(NotesConstants.DB);

		// create a new WorkflowHelper
		WorkflowHelper wh = new WorkflowHelper(NotesConstants.TABLE);
		Triplet<Connection, Savepoint, IRDBMSEngine> transaction = null;
		WorkflowStatementSet statements = null;
		Pair<WorkflowStatementSet, Map<String, Object>> movedItem = null;
		PreparedStatement ps = null;
		try {
			// connect to the db
			transaction = wh.startTransaction(database);

			// get the user
			User user = this.insight.getUser();
			if (user == null) {
				throw new IllegalArgumentException("You are not properly logged in");
			}
			AccessToken token = user.getAccessToken(user.getPrimaryLogin());
			String userId = token.getId();

			// current time
			java.sql.Timestamp currentTime = java.sql.Timestamp.valueOf(LocalDateTime.now());

			// move it to a new stage
			movedItem = wh.moveItem(transaction, 
					id, 
					guid, 
					userId, 
					wh.getSystemUser(),
					NotesConstants.STAGES.PENDING_APPROVAL.getStage(), 
					false, 
					currentTime);

			if(movedItem != null && (statements=movedItem.getValue0()) != null) {
				// create the prepared statement off of the same workflow item
				{
					ps = transaction.getValue0().prepareStatement("UPDATE notes set is_latest=? where id=? and guid=?");
					int psIndex = 1;
					ps.setBoolean(psIndex++, false);
					ps.setString(psIndex++, id);
					ps.setString(psIndex++, guid);
					statements.addPreparedStatement(ps);
				}
				{
					ps = transaction.getValue0().prepareStatement("INSERT INTO notes (id, description, guid, is_latest) VALUES (?,?,?,?)");
					int psIndex = 1;
					ps.setString(psIndex++, (String) movedItem.getValue1().get(WorkflowHelper.ID));
					ps.setString(psIndex++, description);
					ps.setString(psIndex++, (String) movedItem.getValue1().get(WorkflowHelper.GUID));
					ps.setBoolean(psIndex++, true);
					statements.addPreparedStatement(ps);
				}
				
				// only execute if we added to the workflow
				// and able to pull the id to insert the description
				for(PreparedStatement thisPs : statements) {
					thisPs.execute();
				}
				wh.commit(transaction.getValue0());
			}
		} catch (Exception e) {
			// rollback any changes
			wh.rollback(transaction);

			if (e.getMessage() == null || e.getMessage().isEmpty()) {
				throw new SemossPixelException(
						"Error occurred trying to update the note. Detailed message = " + e.getMessage(), false);
			} else {
				throw new IllegalArgumentException(e.getMessage(), e);
			}
		} finally {
			// cleanup any changes
			ConnectionUtils.closePreparedStatement(ps);
			wh.endTransaction(transaction);
		}

		NounMetadata noun = new NounMetadata("Successfully updated note:" + id, PixelDataType.CONST_STRING);
		return noun;
	}

}
