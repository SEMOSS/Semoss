package notes;

public class NotesConstants {
	
	public static final String DB = "61b61da2-f4a5-48d3-be59-d10676ede06b";
	public static final String TABLE = "NOTES_WORKFLOW";
	
	public static enum STAGES {	
		INTAKE("INTAKE"),
	    PENDING_APPROVAL("PENDING_APPROVAL"),
	    REJECTED("REJECTED"),
	    ACCEPTED("ACCEPTED"),
	    DELETED("DELETED"),
	    COMPLETE("COMPLETE");
		
		private String stage;

		private STAGES(String stage) {
			this.stage = stage;
		}

		public String getStage() {
			return this.stage;
		}
	}
}
