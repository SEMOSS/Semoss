package notes;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import prerna.auth.AccessToken;
import prerna.auth.User;
import prerna.engine.impl.rdbms.RDBMSNativeEngine;
import prerna.query.querystruct.SelectQueryStruct;
import prerna.query.querystruct.filters.AndQueryFilter;
import prerna.query.querystruct.filters.OrQueryFilter;
import prerna.query.querystruct.filters.SimpleQueryFilter;
import prerna.query.querystruct.selectors.QueryColumnSelector;
import prerna.sablecc2.om.PixelDataType;
import prerna.sablecc2.om.execptions.SemossPixelException;
import prerna.sablecc2.om.nounmeta.NounMetadata;
import prerna.sablecc2.reactor.AbstractReactor;
import prerna.util.QueryExecutionUtility;
import prerna.util.Utility;
import workflow.WorkflowHelper;

public class GetNotesFromStageReactor extends AbstractReactor {

	public GetNotesFromStageReactor() {
		this.keysToGet = new String[] { "stage" };
	}

	public NounMetadata execute() {
		organizeKeys();

		String stage = this.keyValue.get(this.keysToGet[0]);
		if (stage == null || stage.isEmpty()) {
			throw new IllegalArgumentException("Must provide a valid description");
		}

		// access database
		RDBMSNativeEngine database = (RDBMSNativeEngine) Utility.getEngine(NotesConstants.DB);

		// create a new WorkflowHelper
		WorkflowHelper wh = new WorkflowHelper(NotesConstants.TABLE);

		List<Map<String, Object>> output = new ArrayList<Map<String, Object>>();
		try {
			// get the user
			User user = this.insight.getUser();
			if (user == null) {
				throw new IllegalArgumentException("You are not properly logged in");
			}
			AccessToken token = user.getAccessToken(user.getPrimaryLogin());
			String userId = token.getId();

			// filter the qs to find the current workflow item
			SelectQueryStruct qs = new SelectQueryStruct();
			for (String columnName : wh.getColumns()) {
				qs.addSelector(new QueryColumnSelector(wh.getColumnSelector(columnName)));
			}
			// add the notes selector
			qs.addSelector(new QueryColumnSelector("NOTES__DESCRIPTION"));
						
			// filter to the stage
			qs.addExplicitFilter(SimpleQueryFilter.makeColToValFilter(wh.getColumnSelector("TARGET_STAGE"), "==", stage));
			qs.addExplicitFilter(SimpleQueryFilter.makeColToValFilter(wh.getColumnSelector("IS_LATEST"), "==", true, PixelDataType.BOOLEAN));
			qs.addExplicitFilter(SimpleQueryFilter.makeColToValFilter("NOTES__IS_LATEST", "==", true, PixelDataType.BOOLEAN));

			// add items assigned to the current user or unassigned
			OrQueryFilter orFilters = new OrQueryFilter();

			// items must be assigned to the user and locked or assigned
			AndQueryFilter assignedToMeFilter = new AndQueryFilter();
			assignedToMeFilter.addFilter(SimpleQueryFilter.makeColToValFilter(wh.getColumnSelector("TARGET_USER_ID"), "==", userId));
			assignedToMeFilter.addFilter(SimpleQueryFilter.makeColToValFilter(wh.getColumnSelector("IS_ASSIGNED"), "==", true, PixelDataType.BOOLEAN));
			orFilters.addFilter(assignedToMeFilter);

			// just straight up unassigned
			orFilters.addFilter(SimpleQueryFilter.makeColToValFilter(wh.getColumnSelector("IS_ASSIGNED"), "==", false, PixelDataType.BOOLEAN));
			qs.addExplicitFilter(orFilters);

			// Sort by assigned, unassigned, then time
			qs.addOrderBy(wh.getColumnSelector("IS_ASSIGNED"), "desc"); // get assigned first

			// join between the 2 tables
			qs.addRelation(wh.getColumnSelector("ID"), "NOTES__ID", "inner.join");

			output = QueryExecutionUtility.flushRsToMap(database, qs);
		} catch (Exception e) {
			throw new SemossPixelException(e.getMessage(), e);
		}

		return new NounMetadata(output, PixelDataType.VECTOR);
	}
}
