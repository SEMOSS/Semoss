package workflow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.javatuples.Pair;
import org.javatuples.Triplet;

import prerna.date.SemossDate;
import prerna.engine.api.IRDBMSEngine;
import prerna.engine.api.IRawSelectWrapper;
import prerna.query.querystruct.SelectQueryStruct;
import prerna.query.querystruct.filters.SimpleQueryFilter;
import prerna.query.querystruct.selectors.QueryColumnSelector;
import prerna.rdf.engine.wrappers.WrapperManager;
import prerna.sablecc2.om.PixelDataType;
import prerna.util.ConnectionUtils;

public class WorkflowHelper {

	private static final Logger classLogger = LogManager.getLogger(WorkflowHelper.class);
	
	public static final String ID = "ID";
	public static final String GUID = "GUID";
	public static final String SOURCE_USER_ID = "SOURCE_USER_ID";
	public static final String SOURCE_STAGE = "SOURCE_STAGE";
	public static final String TARGET_USER_ID = "TARGET_USER_ID";
	public static final String TARGET_STAGE = "TARGET_STAGE";
	public static final String IS_ASSIGNED = "IS_ASSIGNED";
	public static final String IS_LOCKED = "IS_LOCKED";
	public static final String IS_LATEST = "IS_LATEST";
	public static final String CREATED_TIMESTAMP = "CREATED_TIMESTAMP";
	public static final String MODIFIED_TIMESTAMP = "MODIFIED_TIMESTAMP";

	private static final String[] COLUMNS = new String[] {
			WorkflowHelper.ID, // unique item id for the workflow
			WorkflowHelper.GUID, // unique step id for the workflow
			WorkflowHelper.SOURCE_USER_ID, // who is working on the item
			WorkflowHelper.SOURCE_STAGE, // where the item is coming from
			WorkflowHelper.TARGET_USER_ID, // who the item is going to
			WorkflowHelper.TARGET_STAGE, // where the item is going
			WorkflowHelper.IS_ASSIGNED, // flag to show if it is assigned to a user
			WorkflowHelper.IS_LOCKED, // flag to check if the item is locked to an individual
			WorkflowHelper.IS_LATEST, // flag to show if it is the latest step
			WorkflowHelper.CREATED_TIMESTAMP, // timestamp when the item was created
			WorkflowHelper.MODIFIED_TIMESTAMP, // timestamp when the item / step was modified
	};

	private static final List<String> COLUMN_LIST = Arrays.asList(COLUMNS);
	private static final String SYSTEM_USER = "SYSTEM";

	private String table = null;
	
	public WorkflowHelper(String table) {
		this.table = table;
	}

	/**
	 * Connect to a database and create the save point
	 */
	public Triplet<Connection, Savepoint, IRDBMSEngine> startTransaction(IRDBMSEngine database) throws Exception {
		// create a connection to insert and a save point
		Connection conn = null;
		Savepoint savepoint = null;
		try {
			conn = database.makeConnection();
			if(!conn.getAutoCommit()) {
        		savepoint = conn.setSavepoint(WorkflowHelper.class.getName() + this.hashCode());
        	}
		} catch (SQLException e) {
			classLogger.error("STACKTRACE: ", e);
			throw new Exception("Error occured establishing connection to database");
		}
		
		return new Triplet<>(conn, savepoint, database);
	}

	/**
	 * Commit changes if there are no errors
	 */
	public void commit(Connection conn) throws Exception {
		if (!conn.getAutoCommit()) {
			conn.commit();
		}
	}

	/**
	 * Roll back changes if there are an error
	 */
	public void rollback(Triplet<Connection, Savepoint, IRDBMSEngine> triplet) {
		if(triplet != null) {
			if (triplet.getValue1() != null) {
				try {
					triplet.getValue0().rollback(triplet.getValue1());
				} catch (Exception e) {
					classLogger.error("STACKTRACE: ", e);
				}
			}
		}
	}

	/**
	 * Destroy anything open
	 */
	public void endTransaction(Triplet<Connection, Savepoint, IRDBMSEngine> triplet) {
		if (triplet.getValue0() != null && triplet.getValue1() != null) {
			try {
				triplet.getValue0().releaseSavepoint(triplet.getValue1());
			} catch (Exception e) {
				classLogger.error("STACKTRACE: ", e);
			}
		}

		if (triplet.getValue0() != null && triplet.getValue2().isConnectionPooling()) {
			ConnectionUtils.closeConnection(triplet.getValue0());
		}
	}

//	/**
//	 * Create a new item
//	 */
//	public Map<String, Object> createItem(String ID, String SOURCE_USER, String SOURCE_STAGE, String TARGET_USER,
//			String TARGET_STAGE, boolean IS_LOCKED, java.sql.Timestamp CREATED_TIMESTAMP,
//			java.sql.Timestamp MODIFIED_TIMESTAMP) throws Exception {
//
//		// store the nextItem
//		Map<String, Object> nextItem = null;
//
//		synchronized (WorkflowHelper.class) {
//			PreparedStatement insertPs = null;
//
//			try {
//				Pair<PreparedStatement, Map<String, Object>> insertPair = createInsert(ID, SOURCE_USER, SOURCE_STAGE,
//						TARGET_USER, TARGET_STAGE, IS_LOCKED, true, CREATED_TIMESTAMP, MODIFIED_TIMESTAMP);
//
//				insertPs = insertPair.getValue0();
//
//				// update it
//				insertPs.executeUpdate();
//
//				// return it
//				nextItem = insertPair.getValue1();
//			} catch (Exception e) {
//				classLogger.error("STACKTRACE: ", e);
//				throw e;
//			} finally {
//				ConnectionUtils.closePreparedStatement(insertPs);
//			}
//		}
//
//		return nextItem;
//	}
	
	/**
	 * 
	 * @param transaction
	 * @param ID
	 * @param GUID
	 * @param SOURCE_USER
	 * @param TARGET_USER
	 * @param TARGET_STAGE
	 * @param IS_LOCKED
	 * @param MODIFIED_TIMESTAMP
	 * @return
	 * @throws Exception
	 */
	public Pair<WorkflowStatementSet, java.util.Map<String, Object>> moveItem(
			Triplet<Connection, Savepoint, IRDBMSEngine> transaction,
			final String ID, 
			final String GUID, 
			final String SOURCE_USER, 
			final String TARGET_USER,
			final String TARGET_STAGE, 
			final boolean IS_LOCKED, 
			final java.sql.Timestamp MODIFIED_TIMESTAMP) throws Exception {
		return moveItem(transaction.getValue2(), transaction.getValue0(), ID, GUID, SOURCE_USER, TARGET_USER, TARGET_STAGE, IS_LOCKED, MODIFIED_TIMESTAMP);
	}

	/**
	 * Move an existing item to the new stage
	 * @param database
	 * @param conn
	 * @param ID
	 * @param GUID
	 * @param SOURCE_USER
	 * @param TARGET_USER
	 * @param TARGET_STAGE
	 * @param IS_LOCKED
	 * @param MODIFIED_TIMESTAMP
	 * @return
	 * @throws Exception
	 */
	public Pair<WorkflowStatementSet, java.util.Map<String, Object>> moveItem(
			IRDBMSEngine database,
			Connection conn,
			final String ID, 
			final String GUID, 
			final String SOURCE_USER, 
			final String TARGET_USER,
			final String TARGET_STAGE, 
			final boolean IS_LOCKED, 
			final java.sql.Timestamp MODIFIED_TIMESTAMP) throws Exception {
		// filter the qs to find the current workflow item
		SelectQueryStruct qs = new SelectQueryStruct();
		for (String columnName : COLUMN_LIST) {
			qs.addSelector(new QueryColumnSelector(getColumnSelector(columnName)));
		}
		qs.addExplicitFilter(SimpleQueryFilter.makeColToValFilter(getColumnSelector(WorkflowHelper.ID), "==", ID));
		qs.addExplicitFilter(SimpleQueryFilter.makeColToValFilter(getColumnSelector(WorkflowHelper.GUID), "==", GUID));
		qs.addExplicitFilter(SimpleQueryFilter.makeColToValFilter(getColumnSelector(WorkflowHelper.IS_LATEST), "==", true, PixelDataType.BOOLEAN));

		WorkflowStatementSet statements = new WorkflowStatementSet();
		Map<String, Object> newItem = null;
		
		synchronized (WorkflowHelper.class) {
			Pair<WorkflowStatementSet, Map<String, Object>> insertPair = null;
			PreparedStatement updatePs = null;
			IRawSelectWrapper iterator = null;

			try {
				iterator = WrapperManager.getInstance().getRawWrapper(database, qs);
				if (!iterator.hasNext()) {
					throw new IllegalArgumentException("Cannot find ID (" + ID + ") or it has moved to a new stage");
				}
				// we should only have 1 row
				Object[] data = iterator.next().getValues();
				if (iterator.hasNext()) {
					throw new IllegalArgumentException("ID (" + ID + ") contains multiple records");
				}

				// create a statement to ignore the old step
				updatePs = createUpdate(conn, false, ID, GUID, true);
				statements.addPreparedStatement(updatePs);
				
				// set the initial data
				String sourceStage = (String) data[COLUMN_LIST.indexOf(WorkflowHelper.TARGET_STAGE)]; // source stage is the previous target
				SemossDate createdDate = (SemossDate) data[COLUMN_LIST.indexOf(WorkflowHelper.CREATED_TIMESTAMP)];

				insertPair = createInsert(
						conn,
						ID, 
						SOURCE_USER, 
						sourceStage,
						TARGET_USER, 
						TARGET_STAGE, 
						IS_LOCKED, 
						true, 
						java.sql.Timestamp.valueOf(createdDate.getLocalDateTime()), 
						MODIFIED_TIMESTAMP
						);

				statements.add(insertPair.getValue0());
				newItem = insertPair.getValue1();
			} catch (Exception e) {
				classLogger.error("STACKTRACE: ", e);
				throw e;
			} finally {
				if (iterator != null) {
					iterator.cleanUp();
				}
			}
		}

		return new Pair<WorkflowStatementSet, Map<String,Object>>(statements, newItem);
	}

	/**
	 * Helper method to get the column list
	 */
	public List<String> getColumns() {
		return COLUMN_LIST;
	}

	/**
	 * Helper method to get the system user
	 */
	public String getSystemUser() {
		return SYSTEM_USER;
	}

	/**
	 * Helper method to convert a column to a column selector
	 */
	public String getColumnSelector(String column) {
		return this.table + "__" + column;
	}

	/** Helper Methods **/

	/**
	 * 
	 * @param ID
	 * @param SOURCE_USER
	 * @param SOURCE_STAGE
	 * @param TARGET_USER
	 * @param TARGET_STAGE
	 * @param IS_LOCKED
	 * @param IS_LATEST
	 * @param CREATED_TIMESTAMP
	 * @param MODIFIED_TIMESTAMP
	 * @return
	 * @throws Exception
	 */
	public Pair<WorkflowStatementSet, java.util.Map<String, Object>> createInsert(
			Connection conn,
			final String ID, 
			final String SOURCE_USER,
			final String SOURCE_STAGE, 
			final String TARGET_USER, 
			final String TARGET_STAGE, 
			final boolean IS_LOCKED, 
			final boolean IS_LATEST,
			final java.sql.Timestamp CREATED_TIMESTAMP, 
			final java.sql.Timestamp MODIFIED_TIMESTAMP) throws Exception {

		// it is assigned if it is not assigned to the system
		boolean isAssigned = !TARGET_USER.equals(SYSTEM_USER);

		// store the item
		Map<String, Object> insertItem = new HashMap<String, Object>();
		insertItem.put(WorkflowHelper.ID, ID);
		insertItem.put(WorkflowHelper.GUID, UUID.randomUUID().toString());
		insertItem.put(WorkflowHelper.SOURCE_USER_ID, SOURCE_USER);
		insertItem.put(WorkflowHelper.SOURCE_STAGE, SOURCE_STAGE);
		insertItem.put(WorkflowHelper.TARGET_USER_ID, TARGET_USER);
		insertItem.put(WorkflowHelper.TARGET_STAGE, TARGET_STAGE);
		insertItem.put(WorkflowHelper.IS_ASSIGNED, isAssigned);
		insertItem.put(WorkflowHelper.IS_LOCKED, IS_LOCKED);
		insertItem.put(WorkflowHelper.IS_LATEST, IS_LATEST);
		insertItem.put(WorkflowHelper.CREATED_TIMESTAMP, CREATED_TIMESTAMP);
		insertItem.put(WorkflowHelper.MODIFIED_TIMESTAMP, MODIFIED_TIMESTAMP);

		return createInsert(conn, insertItem);
	}
	
	/**
	 * 
	 * @param ID
	 * @param SOURCE_USER
	 * @param SOURCE_STAGE
	 * @param TARGET_USER
	 * @param TARGET_STAGE
	 * @param IS_LOCKED
	 * @param IS_LATEST
	 * @param CREATED_TIMESTAMP
	 * @param MODIFIED_TIMESTAMP
	 * @return
	 * @throws Exception
	 */
	public Pair<WorkflowStatementSet, Map<String, Object>> createInsert(Connection conn, Map<String, Object> insertItem) throws Exception {
		// create the prepared statement
		StringBuilder ps = new StringBuilder();
		ps.append("INSERT INTO ").append(this.table).append(" (").append(COLUMNS[0]);
		for (int i = 1; i < COLUMNS.length; i++) {
			ps.append(", ").append(COLUMNS[i]);
		}
		ps.append(") VALUES (?");
		for (int i = 1; i < COLUMNS.length; i++) {
			ps.append(", ?");
		}
		ps.append(")");

		PreparedStatement insertPs = conn.prepareStatement(ps.toString());

		// get the indexes
		int idIdx = COLUMN_LIST.indexOf(WorkflowHelper.ID);
		int guidIdx = COLUMN_LIST.indexOf(WorkflowHelper.GUID);
		int sourceUserIdIdx = COLUMN_LIST.indexOf(WorkflowHelper.SOURCE_USER_ID);
		int sourceStageIdx = COLUMN_LIST.indexOf(WorkflowHelper.SOURCE_STAGE);
		int targetUserIdIdx = COLUMN_LIST.indexOf(WorkflowHelper.TARGET_USER_ID);
		int targetStageIdx = COLUMN_LIST.indexOf(WorkflowHelper.TARGET_STAGE);
		int isAssignedIdx = COLUMN_LIST.indexOf(WorkflowHelper.IS_ASSIGNED);
		int isLockedIdx = COLUMN_LIST.indexOf(WorkflowHelper.IS_LOCKED);
		int isLatestIdx = COLUMN_LIST.indexOf(WorkflowHelper.IS_LATEST);
		int createdTimestampIdx = COLUMN_LIST.indexOf(WorkflowHelper.CREATED_TIMESTAMP);
		int modifiedTimestampIdx = COLUMN_LIST.indexOf(WorkflowHelper.MODIFIED_TIMESTAMP);

		// insert logic
		int insertIndex = 1;
		for (int i = 0; i < COLUMN_LIST.size(); i++) {
			if (i == idIdx) {
				insertPs.setString(insertIndex++, (String) insertItem.get(WorkflowHelper.ID));
			} else if (i == guidIdx) {
				insertPs.setString(insertIndex++, (String) insertItem.get(WorkflowHelper.GUID));
			} else if (i == sourceUserIdIdx) {
				insertPs.setString(insertIndex++, (String) insertItem.get(WorkflowHelper.SOURCE_USER_ID));
			} else if (i == sourceStageIdx) {
				insertPs.setString(insertIndex++, (String) insertItem.get(WorkflowHelper.SOURCE_STAGE));
			} else if (i == targetUserIdIdx) {
				insertPs.setString(insertIndex++, (String) insertItem.get(WorkflowHelper.TARGET_USER_ID));
			} else if (i == targetStageIdx) {
				insertPs.setString(insertIndex++, (String) insertItem.get(WorkflowHelper.TARGET_STAGE));
			} else if (i == isAssignedIdx) {
				insertPs.setBoolean(insertIndex++, (Boolean) insertItem.get(WorkflowHelper.IS_ASSIGNED));
			} else if (i == isLockedIdx) {
				insertPs.setBoolean(insertIndex++, (Boolean) insertItem.get(WorkflowHelper.IS_LOCKED));
			} else if (i == isLatestIdx) {
				insertPs.setBoolean(insertIndex++, (Boolean) insertItem.get(WorkflowHelper.IS_LATEST));
			} else if (i == createdTimestampIdx) {
				insertPs.setTimestamp(insertIndex++, (java.sql.Timestamp) insertItem.get(WorkflowHelper.CREATED_TIMESTAMP));
			} else if (i == modifiedTimestampIdx) {
				insertPs.setTimestamp(insertIndex++, (java.sql.Timestamp) insertItem.get(WorkflowHelper.MODIFIED_TIMESTAMP));
			} else {
				// shouldn't get here
				classLogger.warn("Unable to find column index for " + COLUMN_LIST.get(i) + " at prepared statement index " + insertIndex);
				classLogger.warn("Unable to find column index for " + COLUMN_LIST.get(i) + " at prepared statement index " + insertIndex);
				classLogger.warn("Unable to find column index for " + COLUMN_LIST.get(i) + " at prepared statement index " + insertIndex);
				classLogger.warn("Unable to find column index for " + COLUMN_LIST.get(i) + " at prepared statement index " + insertIndex);
				classLogger.warn("Unable to find column index for " + COLUMN_LIST.get(i) + " at prepared statement index " + insertIndex);
			}
		}

		return new Pair<WorkflowStatementSet, Map<String, Object>>(new WorkflowStatementSet(insertPs), insertItem);
	}


	/**
	 * Create the insert statement
	 * @param IS_LATEST
	 * @param ID
	 * @param GUID
	 * @param CURRENT_IS_LATEST
	 * @return
	 * @throws Exception
	 */
	public PreparedStatement createUpdate(
			Connection conn,
			final boolean IS_LATEST, 
			final String ID, 
			final String GUID, 
			final boolean CURRENT_IS_LATEST)
			throws Exception {

		PreparedStatement updatePs = conn.prepareStatement(
				"UPDATE " + this.table + " SET " + WorkflowHelper.IS_LATEST + " = ? where " 
				+ WorkflowHelper.ID + "=? and " + WorkflowHelper.GUID + "=? and " 
				+ WorkflowHelper.IS_LATEST + "=?");
		
		int updateIndex = 1;
		updatePs.setBoolean(updateIndex++, IS_LATEST);
		updatePs.setString(updateIndex++, ID);
		updatePs.setString(updateIndex++, GUID);
		updatePs.setBoolean(updateIndex++, CURRENT_IS_LATEST);
		return updatePs;
	}
	
}