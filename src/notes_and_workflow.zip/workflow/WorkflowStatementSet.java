package workflow;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import prerna.util.ConnectionUtils;

public class WorkflowStatementSet implements Iterable<PreparedStatement> {

	public List<PreparedStatement> statements = new ArrayList<>();
	
	public WorkflowStatementSet() {
		
	}
	
	public WorkflowStatementSet(PreparedStatement... preparedStatements) {
		for(PreparedStatement ps : preparedStatements) {
			this.statements.add(ps);
		}
	}
	
	public WorkflowStatementSet(Collection<PreparedStatement> preparedStatements) {
		this.statements.addAll(preparedStatements);
	}
	
	public void addPreparedStatement(PreparedStatement ps) {
		this.statements.add(ps);
	}
	
	public void add(WorkflowStatementSet statementSet) {
		this.statements.addAll(statementSet.statements);
	}
	
	public List<PreparedStatement> getStatements() {
		return this.statements;
	}
	
	public void closeAll() {
		for(PreparedStatement ps : statements) {
			ConnectionUtils.closePreparedStatement(ps);
		}
	}

	@Override
	public Iterator<PreparedStatement> iterator() {
		return statements.iterator();
	}
}
